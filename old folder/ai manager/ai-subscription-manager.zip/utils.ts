import { Subscription } from './types';

// Format currency to KRW
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }).format(amount);
};

// Format date to YYYY.MM.DD
export const formatDateKorean = (dateString: string): string => {
  return dateString.replace(/-/g, '.');
};

// Calculate D-Day
export const calculateDDay = (targetDateStr: string): string => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const target = new Date(targetDateStr);
  target.setHours(0, 0, 0, 0);
  
  const diffTime = target.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'D-Day';
  if (diffDays < 0) return `D+${Math.abs(diffDays)}`;
  return `D-${diffDays}`;
};

// Calculate Month and Day for "Every Month X Day" display
export const getPaymentDay = (dateString: string): string => {
    const date = new Date(dateString);
    return `매월 ${date.getDate()}일 결제`;
};

// Helper to get visual styles based on service name
export const getServiceStyles = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('netflix') || n.includes('넷플릭스')) {
        return { 
            icon: 'movie', 
            colorClass: 'text-red-500', 
            bgClass: 'bg-red-500/10',
            borderClass: 'border-red-500/20',
            badgeBg: 'bg-orange-900/30',
            badgeText: 'text-orange-400',
            badgeRing: 'ring-orange-500/20'
        };
    }
    if (n.includes('spotify') || n.includes('스포티파이') || n.includes('music')) {
        return { 
            icon: 'music_note', 
            colorClass: 'text-green-500', 
            bgClass: 'bg-green-500/10',
            borderClass: 'border-green-500/20',
            badgeBg: 'bg-green-900/30',
            badgeText: 'text-green-400',
            badgeRing: 'ring-green-500/20'
        };
    }
    if (n.includes('gpt') || n.includes('ai') || n.includes('claude')) {
        return { 
            icon: 'auto_awesome', 
            colorClass: 'text-white', 
            bgClass: 'bg-white/10',
            borderClass: 'border-white/20',
            badgeBg: 'bg-blue-900/30',
            badgeText: 'text-blue-400',
            badgeRing: 'ring-blue-500/20'
        };
    }
    if (n.includes('adobe') || n.includes('figma') || n.includes('design')) {
        return { 
            icon: 'design_services', 
            colorClass: 'text-blue-500', 
            bgClass: 'bg-blue-500/10',
            borderClass: 'border-blue-500/20',
            badgeBg: 'bg-slate-700',
            badgeText: 'text-slate-300',
            badgeRing: 'ring-slate-500/40'
        };
    }
    // Default
    return { 
        icon: 'credit_card', 
        colorClass: 'text-primary', 
        bgClass: 'bg-primary/20',
        borderClass: 'border-primary/30',
        badgeBg: 'bg-indigo-900/30',
        badgeText: 'text-indigo-400',
        badgeRing: 'ring-indigo-500/20'
    };
};
