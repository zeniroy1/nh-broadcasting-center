import React, { useState } from 'react';
import { Subscription } from '../types';

interface AddFormProps {
    onAdd: (sub: Omit<Subscription, 'id'>) => void;
}

const AddForm: React.FC<AddFormProps> = ({ onAdd }) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [date, setDate] = useState('');

    const handleSubmit = () => {
        if (!name || !price || !date) {
            alert('모든 필드를 입력해주세요.');
            return;
        }

        onAdd({
            name,
            price: Number(price),
            paymentDate: date
        });

        // Reset
        setName('');
        setPrice('');
        setDate('');
    };

    return (
        <div className="bg-card-dark rounded-lg p-6 shadow-md border border-border-dark group relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-indigo-500/10 hover:border-indigo-500/30">
            <div className="absolute inset-0 -translate-x-[150%] group-hover:translate-x-[150%] transition-transform duration-1000 ease-in-out bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-12 pointer-events-none z-0"></div>
            <div className="relative z-10">
                <h3 className="text-lg font-bold text-text-light mb-4 flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">add_circle</span>
                    새 구독 추가
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                    <div className="md:col-span-4">
                        <label className="block text-sm font-medium text-text-muted-dark mb-1.5">서비스명</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                                <span className="material-symbols-outlined text-[20px]">subscriptions</span>
                            </div>
                            <input 
                                type="text" 
                                className="pl-10 block w-full rounded-lg border-border-dark bg-[#374151] text-text-light placeholder-gray-400 shadow-sm focus:border-primary focus:ring-primary sm:text-sm py-2.5 transition-all" 
                                placeholder="예: 넷플릭스"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="md:col-span-3">
                        <label className="block text-sm font-medium text-text-muted-dark mb-1.5">구독료 (₩)</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                                <span className="material-symbols-outlined text-[20px]">attach_money</span>
                            </div>
                            <input 
                                type="number" 
                                className="pl-10 block w-full rounded-lg border-border-dark bg-[#374151] text-text-light placeholder-gray-400 shadow-sm focus:border-primary focus:ring-primary sm:text-sm py-2.5 transition-all" 
                                placeholder="17000"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="md:col-span-3">
                        <label className="block text-sm font-medium text-text-muted-dark mb-1.5">다음 결제일</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                                <span className="material-symbols-outlined text-[20px]">event</span>
                            </div>
                            <input 
                                type="date" 
                                className="pl-10 block w-full rounded-lg border-border-dark bg-[#374151] text-text-light placeholder-gray-400 shadow-sm focus:border-primary focus:ring-primary sm:text-sm py-2.5 transition-all [color-scheme:dark]"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="md:col-span-2">
                        <button 
                            onClick={handleSubmit}
                            className="w-full flex justify-center items-center gap-2 bg-primary hover:bg-primary-hover text-white px-4 py-2.5 rounded-lg text-sm font-medium shadow-sm transition-all active:scale-95"
                        >
                            <span>추가</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddForm;
