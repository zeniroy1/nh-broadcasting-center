import React, { useState, useEffect } from 'react';
import StatsCards from './components/StatsCards';
import AddForm from './components/AddForm';
import SubscriptionList from './components/SubscriptionList';
import Advisor from './components/Advisor';
import { Subscription } from './types';

const App: React.FC = () => {
    const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
    
    // Load from LocalStorage on mount
    useEffect(() => {
        const saved = localStorage.getItem('subscriptions');
        if (saved) {
            try {
                setSubscriptions(JSON.parse(saved));
            } catch (e) {
                console.error("Failed to parse subscriptions", e);
            }
        }
    }, []);

    // Save to LocalStorage whenever subscriptions change
    useEffect(() => {
        localStorage.setItem('subscriptions', JSON.stringify(subscriptions));
    }, [subscriptions]);

    const handleAddSubscription = (newSub: Omit<Subscription, 'id'>) => {
        const sub: Subscription = {
            ...newSub,
            id: Date.now().toString(), // Simple ID generation
        };
        setSubscriptions(prev => [...prev, sub]);
    };

    const handleDeleteSubscription = (id: string) => {
        if(window.confirm('정말 삭제하시겠습니까?')) {
            setSubscriptions(prev => prev.filter(s => s.id !== id));
        }
    };

    // Calculations
    const monthlyTotal = subscriptions.reduce((sum, sub) => sum + sub.price, 0);
    const annualTotal = monthlyTotal * 12;

    return (
        <>
            <header className="bg-card-dark border-b border-border-dark sticky top-0 z-50 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/20 text-primary">
                                <span className="material-symbols-outlined">smart_toy</span>
                            </div>
                            <h1 className="text-xl font-bold tracking-tight text-text-light">AI 구독 비서</h1>
                        </div>
                        <div className="flex items-center gap-4">
                            <div className="relative inline-flex h-8 w-16 items-center rounded-full bg-[#374151] border border-border-dark cursor-pointer transition-colors hover:bg-gray-700 shadow-inner group">
                                <div className="absolute left-1.5 z-10 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-[18px] text-yellow-400 group-hover:text-yellow-300 transition-colors">light_mode</span>
                                </div>
                                <div className="absolute right-1.5 z-10 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-[18px] text-gray-500 opacity-50">dark_mode</span>
                                </div>
                                <div className="absolute h-6 w-6 rounded-full bg-primary shadow-md ring-1 ring-black/10 transition-transform translate-x-[34px] flex items-center justify-center z-20">
                                </div>
                            </div>
                            <div className="h-6 w-px bg-border-dark hidden sm:block"></div>
                            <button className="p-2 text-text-muted-dark hover:text-primary transition-colors">
                                <span className="material-symbols-outlined">notifications</span>
                            </button>
                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm border border-primary/30">
                                JD
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <main className="flex-grow p-4 sm:p-6 lg:p-8">
                <div className="max-w-7xl mx-auto space-y-6">
                    
                    {/* Stats */}
                    <StatsCards monthlyTotal={monthlyTotal} annualTotal={annualTotal} />

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-2 space-y-6">
                            {/* Add Form */}
                            <AddForm onAdd={handleAddSubscription} />
                            
                            {/* List */}
                            <SubscriptionList 
                                subscriptions={subscriptions} 
                                onDelete={handleDeleteSubscription} 
                            />
                        </div>

                        <div className="lg:col-span-1">
                            {/* AI Advisor */}
                            <Advisor subscriptions={subscriptions} />
                        </div>
                    </div>
                </div>
            </main>

            <footer className="bg-card-dark border-t border-border-dark mt-auto py-6">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center text-gray-500 text-sm">
                    © 2024 AI Sub Manager. All rights reserved.
                </div>
            </footer>
        </>
    );
};

export default App;
